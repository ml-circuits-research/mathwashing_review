# Adversarial generator brief (round 2)

You are writing short synthetic ML methods papers for a controlled experiment on peer-review tooling. Everything in `/home/claude/pilot/generator_brief.md` still applies (template, length, rules, file locations, key format) — read it first, and read `/home/claude/pilot/defects.json` for the class definitions.

**New in this round:** the detector you are trying to beat follows the rules in `/home/claude/pilot/skills/skill_v1.md`. Read it. Your job is to write papers whose assigned defect is **real and verifiable** (an expert with unlimited time would confirm it, and your answer key must contain the full derivation), but which a checker following those rules mechanically is likely to **miss** or **misclassify**. Also, for CLEAN papers, write papers that a mechanical checker is likely to **falsely flag**.

## Evasion techniques (use at least two per defective paper; vary them across papers)
- **Spread the evidence.** Put the values needed to evaluate a bound in three different places (one in the setup, one in a table caption, one in a footnote-style sentence in the ablation). Name a constant in the theorem and give its value only implicitly (e.g. "we use the standard choice of Foo et al., which sets c = ..." in the experiments).
- **Nominal use.** For define-and-forget: mention the formal object in the proof sketch or algorithm in a way that does no work (e.g. "by construction, the update stays in H" when it is a plain vector update; a lemma "in the language of the sheaf" whose statement is elementary). The object must be truly inert: removing every mention of it leaves theorem, proof, and algorithm unchanged.
- **Implicit violation.** For assumption mismatch: never name the violating property. Say "ResNet-18 encoder trained end-to-end" instead of "nonconvex"; describe a data pipeline with overlap or temporal ordering rather than saying "non-i.i.d."; state the optimizer only in a table row.
- **Hide the cost.** For complexity: put the expensive operation inside a named subroutine (`Refine(·)`, `Project(·)`) defined in a separate block or described in one prose sentence, and call it inside the main loop; or make the stored object's size depend on a quantity introduced under a different name.
- **Two-step arithmetic.** For numeric inconsistency: make the inconsistency require combining two tables or a table and a prose sentence (e.g. the "relative improvement of 6.1%" only fails when computed against the correct baseline row; the std in Table 2 is impossible given the reported seed count and the per-seed range mentioned in prose).
- **Decoys.** Add one thing that looks like a defect but is fine (a bound that looks large but is well below trivial when computed; an object that looks decorative but is used in one crucial step; a loop that looks quadratic but is over a constant-size set).
- **Confident framing.** As before: no hedging, no "although".

## CLEAN papers this round (trap papers)
Each CLEAN paper must contain **at least two decoys** — features a rule-following checker is likely to flag but which are correct on careful inspection. Examples: a bound with a scary-looking factor that evaluates to 0.2 with the reported values; a theorem for convex losses whose experiments use a model that *sounds* deep but is convex in the trained parameters (e.g. a fixed pretrained frozen encoder + linear head, stated as such); an `Avg` column that rounds differently from the naive mean because it is a weighted average with the weights given in the caption; a nested loop whose inner set has constant size K=8 as stated in the setup. The key must list every decoy and explain why each is not a defect.

## Key format (extended)
Same as before, plus:
```json
"evasion": ["spread", "nominal_use"],
"decoys": [{"looks_like": "VACUOUS_BOUND", "why_fine": "bound evaluates to 0.19 with n=40000, d=32"}],
"derivation": "full arithmetic or logical chain a verifier needs to confirm the defect"
```

## Files
- Papers: `/home/claude/pilot/papers_adv/<paper_id>.md`
- Keys: `/home/claude/pilot/keys_adv/<paper_id>.json`

Efficiency: draft each paper in one Write call, one self-check pass, at most one Edit round. Do not read other papers. When done, reply with one line per paper: `<paper_id> <class> written` and nothing else.
