# Math-washing detection pilot (ML domain) — 2026-09-29

## Layout
- design.md            experiment design and metrics
- defects.json         taxonomy: 5 defect classes + CLEAN, with generator instructions
- generator_brief.md   round-1 generator brief (template + rules)
- generator_brief_adv.md  adversarial round brief (generator has read the detector skill)
- skills/skill_v1.md   detector procedure (5 checks + JSON output)
- skills/baseline_noskill.md  ablation: taxonomy only, no procedure
- papers/     P01–P36  round-1 papers (24 dev + 12 held-out)
- keys/       P01–P36  answer keys (class, location, explanation)
- papers_adv/ A01–A24  adversarial papers (12 dev_adv + 12 heldout_adv), each with 3–6 decoys
- keys_adv/   A01–A24  keys incl. evasion techniques, decoys, full derivation
- assignment.json / assignment_adv.json   paper_id → split, class, topic
- results/v1          sonnet + skill_v1 on P-set
- results/v1_adv      sonnet + skill_v1 on A-set
- results/noskill_adv sonnet, taxonomy only, on A-set
- results/haiku_orig  haiku + skill_v1 on P-set
- results/haiku_adv   haiku + skill_v1 on A-set
- results/*/_score_*.json   scorer output
- verify_dump.json / verification.json   independent verifier input/output (opus)
- score.py            scorer: python3 score.py results/<dir> [--split X] [--assignment assignment_adv.json]

## Headline
sonnet+skill: 50/50 recall, 0/10 FP (P+A). sonnet no-skill: 20/20, 0/4 (A). haiku+skill: 25/30 (P) → 7/20 (A), p=0.0007.

## Re-running a detector
Hide keys/ and keys_adv/ (move them out of the tree), then for each batch of 4 paper IDs launch an agent with:
"Read skills/skill_v1.md and follow it exactly. Papers: <paths>. Read ONLY those. Write results/<run>/<id>.json."
Then restore keys and run score.py.
