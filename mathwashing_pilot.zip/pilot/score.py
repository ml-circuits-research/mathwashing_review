"""Score a detector run.

Usage: python3 score.py <results_dir> [--split dev|heldout|adv] [--assignment assignment.json] [--thr 0.5]
Reads <results_dir>/<paper_id>.json produced by the detector and keys/<paper_id>.json.
"""
import json, glob, sys, os, argparse
from collections import defaultdict

CLASSES = ["ASSUMPTION_MISMATCH", "DEFINE_AND_FORGET", "VACUOUS_BOUND",
           "COMPLEXITY_MISMATCH", "NUMERIC_INCONSISTENCY"]

def load(results_dir, assignment_path, split, thr):
    assign = json.load(open(assignment_path))
    rows = []
    for a in assign:
        if split and a["split"] != split:
            continue
        pid = a["paper_id"]
        rp = os.path.join(results_dir, f"{pid}.json")
        if not os.path.exists(rp):
            rows.append({"pid": pid, "true": a["class"], "reported": None, "missing": True})
            continue
        r = json.load(open(rp))
        reported = {d["type"]: float(d.get("confidence", 1.0)) for d in r.get("defects", [])}
        rows.append({"pid": pid, "true": a["class"],
                     "reported": {t: c for t, c in reported.items() if c >= thr},
                     "all_reported": reported,
                     "verdict": r.get("verdict"), "missing": False})
    return rows

def score(rows):
    out = {}
    tp = defaultdict(int); fn = defaultdict(int); fp = defaultdict(int)
    clean_fp = 0; clean_n = 0; exact = 0; wrong_type = 0; n_def = 0
    per_paper = []
    for r in rows:
        if r["missing"]:
            per_paper.append((r["pid"], r["true"], "MISSING", ""))
            if r["true"] != "CLEAN": fn[r["true"]] += 1; n_def += 1
            else: clean_n += 1
            continue
        rep = set(r["reported"].keys())
        t = r["true"]
        if t == "CLEAN":
            clean_n += 1
            if rep: clean_fp += 1
            else: exact += 1
            for c in rep: fp[c] += 1
            status = "FP" if rep else "OK"
        else:
            n_def += 1
            if t in rep:
                tp[t] += 1
                status = "HIT" if rep == {t} else "HIT+extra"
                if rep == {t}: exact += 1
            else:
                fn[t] += 1
                status = "MISS" if not rep else "WRONG_TYPE"
                if rep: wrong_type += 1
            for c in rep - {t}: fp[c] += 1
        per_paper.append((r["pid"], t, status, ",".join(f"{k}:{v:.2f}" for k, v in sorted(r["reported"].items()))))
    for c in CLASSES:
        rec = tp[c] / (tp[c] + fn[c]) if tp[c] + fn[c] else float("nan")
        prec = tp[c] / (tp[c] + fp[c]) if tp[c] + fp[c] else float("nan")
        out[c] = {"tp": tp[c], "fn": fn[c], "fp": fp[c], "recall": rec, "precision": prec}
    out["_summary"] = {
        "n": len(rows), "n_defective": n_def, "n_clean": clean_n,
        "macro_recall": sum(out[c]["recall"] for c in CLASSES) / len(CLASSES),
        "overall_recall": sum(tp.values()) / n_def if n_def else float("nan"),
        "clean_fp_rate": clean_fp / clean_n if clean_n else float("nan"),
        "exact_match_acc": exact / len(rows),
        "wrong_type": wrong_type,
        "total_fp_flags": sum(fp.values()),
    }
    return out, per_paper

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results_dir")
    ap.add_argument("--split", default=None)
    ap.add_argument("--assignment", default="assignment.json")
    ap.add_argument("--thr", type=float, default=0.5)
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()
    rows = load(args.results_dir, args.assignment, args.split, args.thr)
    out, per_paper = score(rows)
    s = out["_summary"]
    print(f"== {args.results_dir} split={args.split or 'all'} thr={args.thr}  n={s['n']} ==")
    print(f"{'class':24s} {'tp':>3s} {'fn':>3s} {'fp':>3s} {'recall':>7s} {'prec':>6s}")
    for c in CLASSES:
        o = out[c]
        print(f"{c:24s} {o['tp']:3d} {o['fn']:3d} {o['fp']:3d} {o['recall']:7.2f} {o['precision']:6.2f}")
    print(f"overall recall {s['overall_recall']:.2f} | macro recall {s['macro_recall']:.2f} | "
          f"CLEAN FP rate {s['clean_fp_rate']:.2f} | exact-match {s['exact_match_acc']:.2f} | "
          f"wrong-type {s['wrong_type']} | total FP flags {s['total_fp_flags']}")
    if not args.quiet:
        for pid, t, st, rep in per_paper:
            print(f"  {pid} {t:24s} {st:10s} {rep}")
    json.dump({"per_class": {c: out[c] for c in CLASSES}, "summary": s,
               "per_paper": per_paper},
              open(os.path.join(args.results_dir, f"_score_{args.split or 'all'}.json"), "w"), indent=1)

if __name__ == "__main__":
    main()
