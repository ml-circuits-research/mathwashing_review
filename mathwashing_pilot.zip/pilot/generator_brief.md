# Generator brief

You are writing short synthetic ML methods papers for a controlled experiment on peer-review tooling. Each paper you write has an assigned **class** (a defect type or CLEAN) from `/home/claude/pilot/defects.json`. Read that file first: the `generator_instruction` for each class is binding.

## Paper template (use for EVERY paper, regardless of class)
Markdown, 800-1100 words, title, then these sections in order:

1. **Abstract** (5-7 sentences; must state the main theoretical result and the main empirical result, and the algorithm's complexity claim).
2. **Setup and notation** (formal definitions; at least one non-trivial formal object such as a function space, operator, measure, or structured assumption set; a numbered Assumption list).
3. **Method** with `Algorithm 1` as a fenced pseudocode block with explicit `for` loops and explicit per-step operations, followed by a one-sentence complexity claim (time and memory).
4. **Theoretical result**: `Theorem 1` stated with explicit assumptions and an explicit bound with named constants; a 4-8 line proof sketch.
5. **Experiments**: concrete setup (dataset name, n, d, model family, depth, optimizer, schedule, seeds), `Table 1` with baseline vs method on 3-4 datasets plus an `Avg` column, a short ablation (`Table 2`) that repeats at least one configuration from Table 1, and 2-3 sentences of prose quoting specific improvements in points.
6. **Conclusion** (3-4 sentences relating theory and experiments).

Use plausible but fictional dataset names or standard ones. Numbers must look realistic (accuracies 60-95, losses 0.1-2.0, etc.).

## Rules
- The defect (if any) must be **present and unambiguous to a careful expert reader who checks**, but **never announced, hedged, or hinted at** in the text. No "although", "note that our assumptions", "we leave a tighter bound to future work" near the defect.
- Every paper must contain exactly ONE class of defect (its assigned class), and be clean with respect to the other four classes. For CLEAN papers, all five must be absent. Check this explicitly before finishing: for each of A-E, ask "would a checker flag this?" and fix anything that is not the assigned class.
- Style, length, confidence of tone, and structure must be identical across classes. A reader must not be able to guess the class from surface features (length, hedging, section names, presence/absence of a theorem or table).
- Do not reuse the same topic wording, model, or dataset names across your papers.

## Files to write
For each paper spec `(paper_id, class, topic)` you are given:
- `/home/claude/pilot/papers/<paper_id>.md` — the paper. It must NOT contain the class name, the word "defect", or any meta-commentary.
- `/home/claude/pilot/keys/<paper_id>.json` — the answer key:
```json
{"paper_id": "P07", "class": "VACUOUS_BOUND", "location": "Theorem 1 + Sec 5 values", "explanation": "Bound is (d^L) * sqrt(log(1/delta)/n); with d=512, L=8, n=50000, delta=0.05 it evaluates to ~1e21, while loss is in [0,1]. Text calls it 'informative'.", "how_hidden": "bound never evaluated numerically; constants named not expanded"}
```
For CLEAN papers, `class` is `CLEAN`, and `explanation` lists the five checks you performed and why each passes (e.g. "bound evaluates to 0.31 with n=20000, d=64").

When all your papers and keys are written, reply with one line per paper: `<paper_id> <class> written` and nothing else.
