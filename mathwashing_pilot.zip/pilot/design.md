# Pilot: adversarial self-validation for math-washing detection (ML domain)

## Question
Can a detector built from explicit "static-checking" rules (a skill) catch specified math-washing defects in short ML methods papers, and does iterating the skill on observed misses improve held-out performance without inflating false positives on clean papers?

## Roles (separated models to reduce shared blind spots)
- **Generator**: subagent, model `opus`. Receives a paper spec (topic + defect class + defect-specific instruction). Writes the paper and a hidden answer key. Never sees the detector skill (rounds 1-2). In round 3 it sees skill v2 (adversarial).
- **Detector**: subagent, model `sonnet`. Receives the skill text + paper paths only. Never sees keys or generator prompts. Outputs JSON per paper.
- **Orchestrator**: this session. Assigns specs, scores, revises the skill.

## Defect taxonomy
See `defects.json`: A ASSUMPTION_MISMATCH, B DEFINE_AND_FORGET, C VACUOUS_BOUND, D COMPLEXITY_MISMATCH, E NUMERIC_INCONSISTENCY, 0 CLEAN.

## Data
- **dev**: 24 papers, 4 per class. Used to inspect misses and revise the skill.
- **held-out**: 12 papers, 2 per class. Never inspected before scoring; used to measure whether the skill revision generalises.
- **adv**: 12 papers, 2 per class, written by a generator that has read skill v2 and is told to evade it.
- Paper IDs are randomly permuted so class is not inferable from ID.
- Each paper: ~700-1100 words, sections Abstract / Setup & notation / Method + Algorithm 1 / Theoretical result / Experiments (table) / Conclusion. Same template for all classes so surface form carries no signal.

## Protocol
1. Round 1: detector v1 on dev + held-out. Score.
2. Inspect dev misses/false alarms only. Write skill v2.
3. Round 2: detector v2 on dev + held-out. Compare to v1. Held-out delta is the honest number.
4. Round 3: adversarial generator (sees v2) writes adv set. Detector v2 on adv. Recall drop = evasion.

## Metrics
- Per class: recall (paper's true class detected among reported defects with confidence >= 0.5).
- Per class: precision of each reported defect type across all papers.
- CLEAN: false-positive rate (any defect reported with confidence >= 0.5).
- Wrong-type rate: defective paper flagged only with a class different from its true one.
- Exact-match accuracy: reported set == {true class} (or empty for CLEAN).

## Known limitations (to state in any write-up)
- Same model family for generator and detector (different sizes/prompts only). Anchoring to human-labelled retracted/PubPeer papers is required before any real claim.
- Detector processes papers in batches of 4 in one context; slight cross-paper leakage possible.
- Synthetic defects are cleaner than real ones; real math-washing is diffuse.
- Small n; per-class numbers are on 2-4 papers each.
